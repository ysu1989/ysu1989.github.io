/*************************
*	CLAIM		 *	
**************************/

This is the dataset used in the paper, Exploiting Relevance Feedback in Knowledge Graph Search (KDD'15). If you use this dataset, please cite the paper appropriately:

@inproceedings{Su:2015:ERF:2783258.2783320,
 author = {Su, Yu and Yang, Shengqi and Sun, Huan and Srivatsa, Mudhakar and Kase, Sue and Vanni, Michelle and Yan, Xifeng},
 title = {Exploiting Relevance Feedback in Knowledge Graph Search},
 booktitle = {Proceedings of the 21th ACM SIGKDD International Conference on Knowledge Discovery and Data Mining},
 series = {KDD '15},
 year = {2015},
 isbn = {978-1-4503-3664-2},
 location = {Sydney, NSW, Australia},
 pages = {1135--1144},
 numpages = {10},
 url = {http://doi.acm.org/10.1145/2783258.2783320},
 doi = {10.1145/2783258.2783320},
 acmid = {2783320},
 publisher = {ACM},
 address = {New York, NY, USA},
 keywords = {graph query, knowledge graph, relevance feedback},
} 


/*************************
*	DATA		 *	
**************************/

Each file, e.g., 'WIKI/q1', contains one graph query. A typical file looks like this:

WWII; US; Naval Battle{1-3;2-3}
World_War_II; United_States; Battle_of_Midway
World_War_II; United_States; Battle_of_the_Atlantic
World_War_II; United_States; Battle_of_the_Coral_Sea
World_War_II; United_States; Battle_of_Cape_St._George
World_War_II; United_States; Operation_Desecrate_One
...

A file consists two parts: the query (the first line), and the answers in DBpedia (the following lines). A graph query itself has two parts, the node list and the edge list. For example, 'WWII; US; Naval Battle{1-3;2-3}' indicates a query with three nodes labelled 'WWII' (node 1), 'US' (node 2), and 'Naval Battle' (node 3), and two undirected edges, one between node 1 and node 3, and the other between node 2 and node 3. 

An answer is a one-to-one match of DBpedia entities to the nodes of the query. You can easily find an entity on DBpedia, e.g., http://dbpedia.org/page/World_War_II. Redirect links have been resolved. Note that there is no edge match information, and it's not guaranteed that a corresponding edge (either hyperlink or relation), e.g., an edge between 'United_States' and 'Battle_of_the_Atlantic' exists in DBpedia. You need to check your version of DBpedia release to prune the invalid answers, which may vary across different DBpedia releases.

For more details about how the dataset was collected, please refer to the paper.


/*************************
*	CONTACT		 *	
**************************/   

Should you have any questions or comments, please contact ysu@cs ucsb.edu.   


